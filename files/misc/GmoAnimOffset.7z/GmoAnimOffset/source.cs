using PiosGmoLibrary;
using PiosGmoLibrary.GmoChunks;
using static PiosGmoLibrary.GmoEnums;
using static PiosGmoLibrary.Functions;


namespace OffsetAnim
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int AnimIndex = 0;

            if (args.Length < 2)
            {
                Console.WriteLine("Offset Gmo Anim v0.1 by Pioziomgames");
                Console.WriteLine("\nUsage:");
                Console.WriteLine("\tOffsetAnim.exe {InputGmo} {AmountOfFramesToOffsetBy} (optional, 0 by default)AnimationIndex");
                Console.WriteLine("\n\nPress Any Key To Exit");
                Console.ReadKey();
                return;
            }
            else if (args.Length > 2)
            {
                AnimIndex = Int32.Parse(args[2]); 
            }

            float FrameOffset = float.Parse(args[1]);

            if (!File.Exists(args[0]))
                throw new Exception("File doesn't Exist!");

            GmoFile InputFile = new(args[0]);

            int CurAnimIndex = 0;
            bool Edited = false;

            foreach (GmoChunk ModelChunk in InputFile.FileChunk.Children)
            {
                if (ModelChunk.Type == GmoChunkType.Model)
                {
                    for (int i = 0; i < ModelChunk.Children.Count; i++)
                    {
                        if (ModelChunk.Children[i].Type == GmoChunkType.Motion)
                        {
                            if (CurAnimIndex == AnimIndex)
                            {
                                for (int j = 0; j < ModelChunk.Children[i].Children.Count; j++)
                                {
                                    if ((ModelChunk.Children[i].Children[j].Type & ~GmoChunkType.HalfChunk) == GmoChunkType.FrameLoop)
                                    {
                                        GmoFrameLoop FL = (GmoFrameLoop)ModelChunk.Children[i].Children[j];
                                        FL.End += FrameOffset;
                                    }
                                    else if (ModelChunk.Children[i].Children[j].Type == GmoChunkType.FCurve)
                                    {
                                        GmoFCurve FC = (GmoFCurve)ModelChunk.Children[i].Children[j];


                                        for (int k = 0; k < FC.KeyFrames.Count; k++)
                                        {
                                            GmoKeyFrame F = FC.KeyFrames[k];
                                            F.Time += FrameOffset;
                                            FC.KeyFrames[k] = F;
                                        }
                                    }
                                }
                                Edited = true;
                            }
                            CurAnimIndex++;
                        }
                    }
                }
            }

            if (Edited)
            {
                string Out = $"{Path.GetDirectoryName(args[0])}\\{Path.GetFileNameWithoutExtension(args[0])}_OffsetBy{FrameOffset}.gmo";
                InputFile.Save(Out);
                Console.WriteLine($"File saved to: {Out}");
                return;
            }
            else
            {
                if (AnimIndex == 0)
                {
                    Console.WriteLine("No Animations found in the gmo file!");
                }
                else
                {
                    Console.WriteLine($"Index {AnimIndex} is higher than the last animation index!");
                }
                Console.WriteLine("\n\nPress Any Key To Exit");
                Console.ReadKey();
                return;
            }


        }
    }
}