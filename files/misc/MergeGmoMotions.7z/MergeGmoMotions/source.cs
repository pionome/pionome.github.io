using System.Collections;
using PiosGmoLibrary;
using PiosGmoLibrary.GmoChunks;
using static PiosGmoLibrary.Functions;
using static PiosGmoLibrary.GmoEnums;
using ns;


namespace MergeGmoMotions
{
    internal class Program
    {
        static void Quit(bool wait = true)
        {
            if (wait)
            {
                Console.WriteLine("\nPress Any Button to Quit");
                Console.ReadKey();
            }
            Environment.Exit(0);
        }
        static void Main(string[] args)
        {
            ChangeDecimalSeparator();
            Console.WriteLine("MergeGmoMotions 1.0 by Pioziomgames");
            Console.WriteLine("Imports all motions from files in a directory to a single input file");

            string InputPath = String.Empty;
            string InputDir = String.Empty;
            string OutputPath = String.Empty;
            int index = 0;
            bool o = false;
            bool s = false;
            bool ExportGms = false;
            bool Gmo = true;
            bool Gms = true;
            bool wait = true;
            bool usermode = false;
            for (int i = 0; i < args.Length; i++)
            {
                if (o)
                {
                    OutputPath = args[i];
                    o = false;
                }
                else if (!args[i].StartsWith('-') && index == 0)
                {
                    InputPath = args[i];
                    index++;
                }
                else if (!args[i].StartsWith('-') && index == 1)
                    InputDir = args[i];
                else if (args[i].ToLower().StartsWith("-s"))
                    s = true;
                else if (args[i].ToLower().StartsWith("-g"))
                    Gmo = false;
                else if (args[i].ToLower().StartsWith("-m"))
                    Gms = false;
                else if (args[i].ToLower().StartsWith("-o"))
                    o = true;
                else if (args[i].ToLower().StartsWith("-d"))
                    wait = false;
                else if (args[i].Replace(" ", "") != String.Empty)
                    Console.WriteLine("Unrecognized option");

            }

            if (InputPath == "" || InputDir == "")
            {
                Console.WriteLine("\n\nUsage:");
                Console.WriteLine("\tMergeGmoMotions.exe <input file> <input directory> <optional arguments>");
                Console.WriteLine("\tInput File - gmo or gms file that the motions will be added to");
                Console.WriteLine("\tInput Directory - Directory containing gmo and gms/mds files that will be added");
                Console.WriteLine("Arguments:");
                Console.WriteLine("\t-s search sub directories");
                Console.WriteLine("\t-g ignore gmo files");
                Console.WriteLine("\t-m ignore gms/mds files");
                Console.WriteLine("\t-o <path> output file path");
                Console.WriteLine("\t-d don't wait for input");

                if (wait)
                {
                    Console.WriteLine("\n\nPress c to continue in user mode");
                    Console.WriteLine("Press q to quit");
                    while (true)
                    {
                        ConsoleKeyInfo key = Console.ReadKey(true);
                        if (key.Key == ConsoleKey.C)
                        {
                            usermode = true;
                            break;
                        }
                        else if (key.Key == ConsoleKey.Q)
                            Quit(false);
                    }
                }
                else
                {
                    Console.WriteLine("Bad arguments");
                    Quit(false);
                }
            }


            while (!File.Exists(InputPath) && wait)
            {
                Console.Write("Input the path to your file: ");
                InputPath = Console.ReadLine().Replace("\"", "");

                if (File.Exists(InputPath))
                    break;
                else
                {
                    Console.WriteLine("File not found!");
                    InputPath = String.Empty;
                }
            }

            while (!Directory.Exists(InputDir) && wait)
            {
                Console.Write("Input the path to the folder with your files: ");
                InputDir = Console.ReadLine().Replace("\"", "");

                if (Directory.Exists(InputDir))
                    break;
                else
                {
                    Console.WriteLine("Directory not found!");
                    InputDir = String.Empty;
                }
            }

            if (OutputPath == String.Empty)
                OutputPath = Path.GetDirectoryName(InputPath) + "\\" + Path.GetFileNameWithoutExtension(InputPath) + "_Motions";

            if (s == false && wait && usermode)
            {
                Console.WriteLine("Search subdirectories? (y/n)");

                while(true)
                {
                    ConsoleKeyInfo k = Console.ReadKey(true);
                    if (k.Key == ConsoleKey.Y)
                    {
                        s = true;
                        break;
                    }
                    else if (k.Key == ConsoleKey.N)
                        break;
                }
            }

            if (!Directory.Exists(InputDir))
            {
                Console.WriteLine($"Directory: {InputDir} was not found!");
                Quit(wait);
            }

            string[] Files;
            if (s)
                Files = Directory.GetFiles(InputDir, "*", SearchOption.AllDirectories);
            else
                Files = Directory.GetFiles(InputDir, "*", SearchOption.TopDirectoryOnly);

            NumericComparer nc = new();
            Array.Sort(Files, nc);


            GmoFile InputModel;

            Console.WriteLine($"Reading: {InputPath}...");

            if (!File.Exists(InputPath))
            {
                Console.WriteLine($"File: {InputPath} was not found!");
                Quit(wait);
            }

            if (Path.GetExtension(InputPath.ToLower()) == ".gmo")
            {
                InputModel = new(InputPath);
                OutputPath += ".gmo";
            }    
            else
            {
                InputModel = GmoFile.ReadFromText(InputPath);
                OutputPath += ".gms";
                ExportGms = true;
            }

            
            InputModel.MakeChunkNamesUnique();

            List<string> BoneNames = new();

            GmoChunk? ModelChunk = null;
            for (int i = 0; i < InputModel.FileChunk.Children.Count; i++)
            {
                if (InputModel.FileChunk.Children[i].Type == GmoChunkType.Model)
                {
                    ModelChunk = InputModel.FileChunk.Children[i];

                    for (int j = 0; j < ModelChunk.Children.Count; j++)
                        if (ModelChunk.Children[j].Type == GmoChunkType.Bone)
                            BoneNames.Add(ModelChunk.Children[j].Name);
                }
            }

            if (ModelChunk == null)
            {
                Console.WriteLine("No Model Chunk Found in the input file");
                Quit(wait);
                return;
            }


            
            List<GmoChunk> NewMotions = new();

            Console.WriteLine($"\nProcessing files in: {InputDir}...");
            for (int i = 0; i < Files.Length; i++)
            {
                GmoFile AnimationFile;
                if (Path.GetExtension(Files[i].ToLower()) == ".gmo" && Gmo)
                {
                    Console.WriteLine($"\tReading: {Files[i]}...");
                    AnimationFile = new GmoFile(Files[i]);
                }
                else if (Gms && (Path.GetExtension(Files[i].ToLower()) == ".gms" || Path.GetExtension(Files[i].ToLower()) == ".mds") )
                {
                    Console.WriteLine($"\tReading: {Files[i]}...");
                    AnimationFile = GmoFile.ReadFromText(Files[i]);
                }
                else
                    continue;

                AnimationFile.MakeChunkNamesUnique();

                List<string> MotionsBoneNames = new();

                for (int j = 0; j < AnimationFile.FileChunk.Children.Count; j++)
                {
                    if (AnimationFile.FileChunk.Children[j].Type == GmoChunkType.Model)
                    {
                        List<GmoChunk> Motions = AnimationFile.FileChunk.Children[j].Children.FindAll(x => x.Type == GmoChunkType.Motion);

                        for (int k = 0; k < AnimationFile.FileChunk.Children[j].Children.Count; k++)
                            if (AnimationFile.FileChunk.Children[j].Children[k].Type == GmoChunkType.Bone)
                                BoneNames.Add(AnimationFile.FileChunk.Children[j].Children[k].Name);


                        for (int k = 0; k < Motions.Count; k++)
                        {
                            for (int l = 0; l < Motions[k].Children.Count; l++)
                            {
                                if (Motions[k].Children[l].Type == GmoChunkType.Animate)
                                {
                                    GmoAnimate animate = (GmoAnimate)Motions[k].Children[l];

                                    if ((GmoChunkType)animate.BlockRef.Type == GmoChunkType.Bone)
                                    {
                                        if (BoneNames.Contains(MotionsBoneNames[animate.BlockRef.Index]))
                                        {
                                            animate.BlockRef.Index = (ushort)BoneNames.IndexOf(MotionsBoneNames[animate.BlockRef.Index]);
                                            Motions[k].Children[l] = animate;
                                        }
                                    }
                                }
                            }


                            ModelChunk.Children.Add(Motions[k]);
                        }
                    }
                }
            }

            if (ExportGms)
                File.WriteAllText(OutputPath, InputModel.SaveAsText());
            else
                InputModel.Save(OutputPath);

            Console.WriteLine($"\nSaved to: {OutputPath}");
            Console.Beep();
            Quit(wait);

        }
    }
}


//(c) Vasian Cepa 2005
// Version 2
namespace ns
{
    public class NumericComparer : IComparer
    {
        public NumericComparer()
        { }

        public int Compare(object? x, object? y)
        {
            if ((x is string) && (y is string))
            {
                return StringLogicalComparer.Compare((string)x, (string)y);
            }
            return -1;
        }
    }//EOC

    // emulates StrCmpLogicalW, but not fully
    public class StringLogicalComparer
    {
        public static int Compare(string s1, string s2)
        {
            //get rid of special cases
            if ((s1 == null) && (s2 == null)) return 0;
            else if (s1 == null) return -1;
            else if (s2 == null) return 1;

            if ((s1.Equals(string.Empty) && (s2.Equals(string.Empty)))) return 0;
            else if (s1.Equals(string.Empty)) return -1;
            else if (s2.Equals(string.Empty)) return -1;

            //WE style, special case
            bool sp1 = Char.IsLetterOrDigit(s1, 0);
            bool sp2 = Char.IsLetterOrDigit(s2, 0);
            if (sp1 && !sp2) return 1;
            if (!sp1 && sp2) return -1;

            int i1 = 0, i2 = 0; //current index
            int r = 0; // temp result
            while (true)
            {
                bool c1 = Char.IsDigit(s1, i1);
                bool c2 = Char.IsDigit(s2, i2);
                if (!c1 && !c2)
                {
                    bool letter1 = Char.IsLetter(s1, i1);
                    bool letter2 = Char.IsLetter(s2, i2);
                    if ((letter1 && letter2) || (!letter1 && !letter2))
                    {
                        if (letter1 && letter2)
                        {
                            r = Char.ToLower(s1[i1]).CompareTo(Char.ToLower(s2[i2]));
                        }
                        else
                        {
                            r = s1[i1].CompareTo(s2[i2]);
                        }
                        if (r != 0) return r;
                    }
                    else if (!letter1 && letter2) return -1;
                    else if (letter1 && !letter2) return 1;
                }
                else if (c1 && c2)
                {
                    r = CompareNum(s1, ref i1, s2, ref i2);
                    if (r != 0) return r;
                }
                else if (c1)
                {
                    return -1;
                }
                else if (c2)
                {
                    return 1;
                }
                i1++;
                i2++;
                if ((i1 >= s1.Length) && (i2 >= s2.Length))
                {
                    return 0;
                }
                else if (i1 >= s1.Length)
                {
                    return -1;
                }
                else if (i2 >= s2.Length)
                {
                    return -1;
                }
            }
        }

        private static int CompareNum(string s1, ref int i1, string s2, ref int i2)
        {
            int nzStart1 = i1, nzStart2 = i2; // nz = non zero
            int end1 = i1, end2 = i2;

            ScanNumEnd(s1, i1, ref end1, ref nzStart1);
            ScanNumEnd(s2, i2, ref end2, ref nzStart2);
            int start1 = i1; i1 = end1 - 1;
            int start2 = i2; i2 = end2 - 1;

            int nzLength1 = end1 - nzStart1;
            int nzLength2 = end2 - nzStart2;

            if (nzLength1 < nzLength2) return -1;
            else if (nzLength1 > nzLength2) return 1;

            for (int j1 = nzStart1, j2 = nzStart2; j1 <= i1; j1++, j2++)
            {
                int r = s1[j1].CompareTo(s2[j2]);
                if (r != 0) return r;
            }
            // the nz parts are equal
            int length1 = end1 - start1;
            int length2 = end2 - start2;
            if (length1 == length2) return 0;
            if (length1 > length2) return -1;
            return 1;
        }

        //lookahead
        private static void ScanNumEnd(string s, int start, ref int end, ref int nzStart)
        {
            nzStart = start;
            end = start;
            bool countZeros = true;
            while (Char.IsDigit(s, end))
            {
                if (countZeros && s[end].Equals('0'))
                {
                    nzStart++;
                }
                else countZeros = false;
                end++;
                if (end >= s.Length) break;
            }
        }

    }//EOC
}