using PiosGmoLibrary;
using PiosAmdLibrary;
using static PiosGmoLibrary.GmoEnums;
using static PiosGmoLibrary.Functions;


namespace DelChunk
{
    internal class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 1)
            {
                if (args[0].ToLower() == "-l")
                {
                    Console.WriteLine("DelChunk v0.1 by Pioziomgames");


                    List<string> values = Enum.GetValues(typeof(GmoChunkType))
                        .Cast<GmoChunkType>()
                        .Select(v => v.ToString())
                        .ToList();
                    Console.WriteLine("\nPossible chunk types:");

                    for (int i = 0; i < values.Count; i++)
                    {
                        if (values[i] != "BaseReserved" && values[i] != "Block" && values[i] != "BasePrivate" && values[i] != "BasePublic" && values[i] != "HalfChunk")
                            Console.WriteLine("  " + values[i]);
                    }
                }
                return;
            }
            if (args.Length < 2)
            {
                Console.WriteLine("DelChunk v0.1 by Pioziomgames");
                Console.WriteLine("Removes a specified chunk type from all amd and gmo files in a directory");
                Console.WriteLine("\nUsage:");
                Console.WriteLine("\tDelChunk.exe {InputDir} (multiple allowed){chunktype}");
                Console.WriteLine("\tDelChunk.exe -l (print all allowed chunk types)");
                Console.WriteLine("\nExamples:");
                Console.WriteLine("\tDelChunk.exe \"C:\\inputDir\" Specular");
                Console.WriteLine("\tDelChunk.exe \"C:\\inputDir\" Emission BlindData");
                Console.WriteLine("\n\nPress Any Key To Exit");
                Console.ReadKey();
                return;
            }



            List<GmoChunkType> InputTypes = new();

            for (int i = 0; i < args.Length - 1; i++)
            {
                GmoChunkType input = GmoChunkType.Block;
                ParseEnum(args[i + 1], input.GetType(), out Enum S);
                input = (GmoChunkType)S;
                InputTypes.Add(input);
            }
            

            if (!Directory.Exists(args[0]))
                throw new Exception("Directory doesn't Exist!");


            string[] gmofiles = Directory.GetFiles(args[0], "*.gmo");
            string[] amdfiles = Directory.GetFiles(args[0], "*.amd");

            string[] files = gmofiles.Union(amdfiles).ToArray();

            int h = 0;
            foreach (string file in files)
            {
                Console.WriteLine($"File {h+1}/{files.Length}");
                h++;
                string ext = Path.GetExtension(file);

                if (ext.ToLower() == ".amd")
                {
                    bool Edited = false;
                    int AmdIndex = -1;
                    Amd InputAmd = new(file);
                    for (int i = 0; i < InputAmd.Chunks.Count; i++)
                    {
                        if (InputAmd.Chunks[i].Flags == 257)
                            AmdIndex = i;
                    }

                    GmoFile gmo = new(InputAmd.Chunks[AmdIndex].Data);

                    RemoveChunkType(gmo.FileChunk, InputTypes, ref Edited);

                    if (Edited)
                    {
                        InputAmd.Chunks[AmdIndex].Data = gmo.Save();
                        Console.WriteLine($"Saving {Path.GetFileName(file)}...");
                        InputAmd.Save(file);
                    }
                }
                else if (ext.ToLower() == ".gmo")
                {
                    GmoFile gmo = new(file);
                    bool Edited = false;
                    RemoveChunkType(gmo.FileChunk, InputTypes, ref Edited);

                    if (Edited)
                    {
                        gmo.Save(file);
                        Console.WriteLine($"Saving {Path.GetFileName(file)}...");
                    }
                }

                
            }

            Console.WriteLine("All files Saved");
        }
        static void RemoveChunkType(GmoChunk parent, List<GmoChunkType> chunks, ref bool edited)
        {
            List<int> ToDelete = new();
            for (int i = 0; i < parent.Children.Count;i++)
            {
                if (chunks.Contains(parent.Children[i].Type & ~ GmoChunkType.HalfChunk))
                    ToDelete.Add(i);
            }
            ToDelete = ToDelete.OrderByDescending(x => x).ToList();
            if (ToDelete.Count > 0)
                edited = true;
            for (int i = 0; i < ToDelete.Count; i++)
                parent.Children.RemoveAt(ToDelete[i]);

            for (int i = 0;i < parent.Children.Count;i++)
                RemoveChunkType(parent.Children[i], chunks, ref edited);
        }
    }

    
}