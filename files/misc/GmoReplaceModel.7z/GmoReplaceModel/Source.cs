using PiosGmoLibrary;
using GmoEditor;
using static GmoEditor.GmoTree;
using static GmoEditor.GmoTree.GmoModelTree;

namespace GmoReplaceModel
{
    internal class Program
    {
        //Code before Main is straight up copied from GmoEditor
        private static List<string> ExistingBones = new List<string>();
        private static GmoModelTree model;
        private static string CreateBone(GmoTreeBone NewBone)
        {
            if (NewBone.Parent != null)
            {
                NewBone.Parent = model.Bones[ExistingBones.IndexOf(CreateBone(NewBone.Parent))];
                if (!NewBone.Parent.Children.Contains(NewBone))
                    NewBone.Parent.Children.Add(NewBone);
            }
            string thisPath = NewBone.GetPath();
            bool alreadyAdded = false;
            if (!ExistingBones.Contains(thisPath))
            {
                NewBone.Tree = model;
                NewBone.Children.Clear(); //Don't add the children of this bone to the new tree yet
                model.Bones.Add(NewBone);
                ExistingBones.Add(thisPath);
            }
            else
            {
                GmoTreeBone current = model.Bones[ExistingBones.IndexOf(thisPath)];
                if (current.BlendBones == null || current.BlendBones.Count == 0)
                {
                    current.BlendBones = new List<GmoTreeBone>();
                    for (int i = 0; i < NewBone.BlendBonesCount; i++)
                    {
                        current.BlendBones.Add(model.Bones[ExistingBones.IndexOf(CreateBone(NewBone.BlendBones[i]))]);
                    }
                    alreadyAdded = true;
                    if (current.DrawParts == null)
                        current.DrawParts = new List<GmoTreePart>();
                    for (int i = 0; i < NewBone.DrawParts.Count; i++)
                    {
                        current.DrawParts.Add(NewBone.DrawParts[i]);
                    }
                }
                else
                {
                    NewBone.Tree = model;
                    NewBone.Children.Clear();
                    model.Bones.Add(NewBone);
                    ExistingBones.Add(thisPath);
                }
            }

            if (!alreadyAdded)
            {
                for (int i = 0; i < NewBone.BlendBonesCount; i++)
                {
                    NewBone.BlendBones[i] = model.Bones[ExistingBones.IndexOf(CreateBone(NewBone.BlendBones[i]))];
                }
            }

            for (int i = 0; i < NewBone.DrawParts.Count; i++)
            {
                if (!model.Parts.Contains(NewBone.DrawParts[i]))
                {
                    NewBone.DrawParts[i].Tree = model;
                    model.Parts.Add(NewBone.DrawParts[i]);
                    for (int j = 0; j < NewBone.DrawParts[i].MeshCount; j++)
                    {
                        NewBone.DrawParts[i].Meshes[j].Tree = model;
                        if (NewBone.DrawParts[i].Meshes[j].Material != null &&
                            !model.Materials.Contains(NewBone.DrawParts[i].Meshes[j].Material))
                        {
                            NewBone.DrawParts[i].Meshes[j].Material.Tree = model;
                            foreach (GmoTreeLayer layer in NewBone.DrawParts[i].Meshes[j].Material.Layers)
                            {
                                layer.Tree = model;
                                if (layer.Texture != null)
                                {
                                    if (!model.Textures.Contains(layer.Texture))
                                    {
                                        layer.Texture.Tree = model;
                                        model.Textures.Add(layer.Texture);
                                    }
                                }
                            }
                            int matIndex = model.Materials.FindIndex(x => x.Name == NewBone.DrawParts[i].Meshes[j].Material.Name);
                            if (matIndex > -1)
                            {
                                foreach (GmoTreePart OgPart in model.Parts)
                                {
                                    foreach (GmoTreeMesh OgMesh in OgPart.Meshes.FindAll(x => x.Material == model.Materials[matIndex]))
                                    {
                                        OgMesh.Material = NewBone.DrawParts[i].Meshes[j].Material;
                                    }
                                }
                                model.Materials.RemoveAt(matIndex);
                            }
                            model.Materials.Add(NewBone.DrawParts[i].Meshes[j].Material);
                        }
                    }
                }
            }
            return thisPath;
        }

        static void Main(string[] args)
        {
            if (args.Length < 3)
            {
                Console.WriteLine("GmoReplaceModel 1.0 by Pioziomgames");
                Console.WriteLine("A program to replace model data inside of a gmo model while leaving any other data left over");
                Console.WriteLine("\nUsage:");
                Console.WriteLine("GmoReplaceModel.exe {originalGmoPath} {gmoWithNewDataPath} {outputGmoPath} (optional){namesOfPartsToNotRemove}");
                Console.WriteLine("namesOfPartsToNotRemove refers to parts in the original gmo and each name is it's own argument");
                Console.WriteLine("\nExample:");
                Console.WriteLine(@"GmoReplaceModel.exe C:\og.gmo C:\data.gmo c:\output.gmo Glasses Hair");

                Console.WriteLine("\n\nPress Any Button to Quit");
                Console.ReadKey();
                return;
            }


            PiosGmoLibrary.Functions.Initialize();
            Console.WriteLine("Opening: " + args[0]);
            GmoFile OgFile = new GmoFile(args[0]);
            OgFile.MakeChunkNamesUnique();
            OgFile.ApplyVertexOffsets();
            model = new(OgFile);
            Console.WriteLine("Opening: " + args[1]);
            GmoFile NewFile = new GmoFile(args[1]);
            NewFile.MakeChunkNamesUnique();
            NewFile.ApplyVertexOffsets();
            GmoModelTree NewData = new(NewFile);

            string[] partsToLeave = { "" };
            if (args.Length > 3)
            {
                partsToLeave = args.Skip(3).ToArray();
            }

            model.Parts.RemoveAll(x => !partsToLeave.Contains(x.Name));

            for (int i = 0; i < model.BoneCount; i++)
            {
                model.Bones[i].DrawParts.RemoveAll(x => !partsToLeave.Contains(x.Name));
            }

            for (int i = 0; i < model.BoneCount; i++)
                ExistingBones.Add(model.Bones[i].GetPath());

            foreach (GmoTreeBone bone in NewData.Bones)
                CreateBone(bone);

            GmoFile output = model.ToGmo();
            output.MakeChunkNamesUnique();
            Console.WriteLine("Saving output to: " + args[2]);
            output.Save(args[2]);
        }
    }
}